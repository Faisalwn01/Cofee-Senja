<?php
include 'koneksi.php';
$queryMenu = mysqli_query($dbconnect, "SELECT menu.*, kategori.nama as kategori_nama FROM menu JOIN kategori ON menu.kategori_id = kategori.id");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Coffee Senja</title>

<!-- font -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,400;1,700&display=swap" rel="stylesheet">


<!--Feather Icons -->
<script src="https://unpkg.com/feather-icons"></script>



    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    
<!-- Navbar start -->
<nav class="navbar">
    <a href="#" class="navbar-logo">Coffee<span>Senja.</span></a>


    <div class="navbar-nav">
        <a href="#">Home</a>
        <a href="#about">Tentang Kami</a>
        <a href="#Menu">Menu</a>
        <a href="#contact">Kontak</a>
    </div>


   <div class="navbar-extra">
    <a href="#" id="search"><i data-feather="search"></i></a>
    <a href="#" id="shopping-cart"><i data-feather="shopping-cart"></i></a>
    <a href="#" id="list"><i data-feather="list"></i></a>
   </div> 

</nav>


<!-- Navbar end -->


<!-- Hero Section start -->
<section class="hero" id="Home">
    <main class="content">
        <h1>Mari Nikmati Secangkir <span>Kopi</span></h1>
        <p>Hidup ini terlalu singkat untuk kopi yang buruk, pilihlah dengan bijak dan nikmati setiap tegukan.</p>
        <a href="#" class="cta">Beli Sekarang</a>
    </main>
</section>

<!-- Hero Section end -->


<!-- About Section Start -->
<section id="about" class="about">
<h2><span>Tentang</span>Kami</h2>


<div class="row">
    <div class="about-img">
        <img src="img/tentang-kami.jpg" alt="Tentang Kami">
    </div>
    <div class="content">
        <h3>Kenapa memilih kopi kami?</h3>
        <p>Ingatlah bahwa Anda mempunyai kekuatan untuk membuat perbedaan, bahkan melalui online yang sederhana</p>
        <p>Tetap positif dan lihat sisi baik dalam setiap situasi, web dapat membantu Anda terhubung dengan pengaruh positif.</p>
    </div>
</div>
</section>

<!-- About Section end -->


<section id="Menu" class="Menu">
        <h2><span>Menu</span>Kami</h2>
        <p>Silahkan memilih menu yang tersedia di coffee senja kami</p>

        <div class="row">
            <?php
            while ($data = mysqli_fetch_array($queryMenu)) {
            ?>
                <div class="Menu-card col-md-4">
                    <img src="img/<?php echo $data['foto']; ?>" alt="<?php echo $data['nama']; ?>" class="Menu-card-img">
                    <h3 class="Menu-card-title">- <?php echo $data['nama']; ?> -</h3>
                    <p class="Menu-card-price">IDR <?php echo $data['harga']; ?>K</p>
                </div>
            <?php
            }
            ?>
        </div>
    </section>



<!-- Contact Section Start -->
<section id="Contact" class="Contact">
    <h2><span>Kontak</span>Kami</h2>
    <p>banyak layanan pesan-antar makanan yang memiliki nilai pesanan minimum agar pengirimannya hemat biaya dan menguntungkan</p>



    <div class="row">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d63245.983719355485!2d110.33364532885086!3d-7.803163419720803!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e7a5787bd5b6bc5%3A0x21723fd4d3684f71!2sYogyakarta%2C%20Kota%20Yogyakarta%2C%20Daerah%20Istimewa%20Yogyakarta!5e0!3m2!1sid!2sid!4v1714732911643!5m2!1sid!2sid" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade" class="maps"></iframe>

        <form action="">
           <div class="input-group">
            <i data-feather="user"></i>
            <input type="text" placeholder="nama">
           </div> 

           <div class="input-group">
            <i data-feather="mail"></i>
            <input type="text" placeholder="email">
           </div> 

           <div class="input-group">
            <i data-feather="phone"></i>
            <input type="text" placeholder="no hp">
           </div> 
           <button type="submit" class="btn">kirim pesan</button>
        </form>



    </div>
</section>




<!-- Contact Section end -->



<!-- Footer Start -->
<footer>
    <div class="socials">
       <a href="#"><i data-feather="instagram"></i></a>
       <a href="#"><i data-feather="twitter"></i></a> 
       <a href="#"><i data-feather="facebook"></i></a> 
    </div>



    <div class="links">
        <a href="#home">Home</a>
        <a href="#about">Tentang Kami</a>
        <a href="#menu">Menu</a>
        <a href="#contact">Kontak</a>
    </div>


    <div class="credit">
       <p>Created by <a href="">CoffeeSenja</a>
    . l &copy; 2024.</p> 
    </div>
</footer>





<!-- Footer end -->




<!-- Feather Icons -->
<script>
    feather.replace();
  </script>


<!-- My Javascript -->
<script src="js/script.js"></script>
</body>
</html>