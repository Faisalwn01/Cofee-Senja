// Toggle class active
const navbarnav = document.querySelector('.navbar-nav');
// Ketika list menu di klik
document.querySelector('#list').onclick = () => {
    navbarnav.classList.toggle('active');
};

// Klik di luar sidebar untuk menghilangkan nav
const list = document.querySelector('#list');

document.addEventListener('click', function(e){
    if(!list.contains(e.target) && !navbarnav.contains(e.target)) {
       navbarnav.classList.remove('active'); 
    }
});