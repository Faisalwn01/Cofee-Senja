<?php
$host = "127.0.0.1:3307"; // ganti dengan nama host Anda
$user = "root"; // ganti dengan nama pengguna MySQL Anda
$pass = ""; // ganti dengan kata sandi MySQL Anda
$db = "cf"; // ganti dengan nama database Anda

// Membuat koneksi
$dbconnect = new mysqli($host, $user, $pass, $db);

// Memeriksa koneksi
if ($dbconnect-> connect_error) {
    echo "Koneksi Berhasil".$dbconnect->connect_error;
}

