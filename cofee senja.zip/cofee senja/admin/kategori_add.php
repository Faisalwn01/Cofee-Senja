<?php
session_start();
include '../koneksi.php';
if (isset($_POST['simpan'])) {
    

    $nama = $_POST['nama'];
   

    // Save to the database
    mysqli_query($dbconnect, "INSERT INTO kategori VALUES ('', '$nama')");

    $_SESSION['success'] = 'Berhasil menambahkan data';

    // Redirect to the list role page
    header("location: kategori.php");
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Tambah role</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>
    <div class="container">
        <h1>Tambah</h1>
        <form method="post">
            <div class="form-group">
                <label>Nama kategori</label>
                <input type="text" name="nama" class="form-control" placeholder="Nama role">
            </div>
            <input type="submit" name="simpan" value ="simpan" class="btn btn-primary">
            <a href="kategori.php" class="btn btn-primary">kembali</a>
        </form>
    </div>
</body>

</html>
