<?php
session_start();
include '../koneksi.php';
?>

<!DOCTYPE html>
<html>

<head>
    <title>Login</title>
    <link 
    href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-BVYiiSIFeK1dGmJRAkyCuHAHRg320mUCww70n3RYdg4Va+PmSTsz/K68vbdEjh4u" 
    crossorigin="anonymous">
</head>

<body>
    <div class="container">
        <h1>Login</h1>
        <form method="post">
            <div class="form-group">
                <label for ="exampleInputEmail1">Username</label>
                <input type="text" name="username" class="form-control" id="username">
            </div>
            <div class="form-group">
                <label for ="exampleInputPassword">Password</label>
                <input type="password" name="password" class="form-control" id="password">
            </div>
            <input type="submit" name="masuk" value="Masuk" class="btn btn-default">
        </form>
    </div>
    <div class="mt-3">
    <?php


if (isset($_POST['masuk'])) 
{
    $username = htmlspecialchars($_POST['username']);
    $password = htmlspecialchars($_POST['password']);

    
    $query=mysqli_query($dbconnect,"SELECT * FROM users WHERE username='$username'");
    //hasil dari data
    $data = mysqli_fetch_array($query);
    //mendapatkan nilai jumlah data
    $countdata = mysqli_num_rows($query);

   
    
    if ($countdata>0) {
        if (password_verify($password, $data['password'])) {
        $_SESSION['username'] = $data['username'];
        $_SESSION['login'] = true;
        
        
        header("location: index.php");
        }
        else {
        
        ?>
        <div class="alert alert-warning" role="alert">
            password salah
        </div>
        <?php
        }
    } 
    else 
    {
        ?>
        <div class="alert alert-warning" role="alert">
            akun tidak ada
        </div>
        <?php
    }
}
?>
    </div>
</body>

</html>
