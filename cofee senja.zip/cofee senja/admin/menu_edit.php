<?php
include '../koneksi.php';
session_start();

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = mysqli_query($dbconnect, "SELECT * FROM menu WHERE id = $id");
    $data = mysqli_fetch_array($query);

    $nama = $data['nama'];
    $kategori_id = $data['kategori_id'];
    $harga = $data['harga'];
    $detail = $data['detail'];
    $ketersediaan_stok = $data['ketersediaan_stok'];
    $foto = $data['foto'];
}

if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $kategori_id = $_POST['kategori'];
    $harga = $_POST['harga'];
    $detail = $_POST['detail'];
    $ketersediaan_stok = $_POST['ketersediaan_stok'];

    $target_dir = "../img/";
    $nama_file = basename($_FILES["foto"]["name"]);
    $image_size = $_FILES["foto"]["size"];
    $target_file = $target_dir . $nama_file;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Validasi file jika ada file yang diupload
    if ($image_size > 0 && ($imageFileType == "jpg" || $imageFileType == "png" || $imageFileType == "jpeg")) {
        if (move_uploaded_file($_FILES["foto"]["tmp_name"], $target_file)) {
            $foto = $nama_file;
        } else {
            $_SESSION['error'] = 'Gagal mengupload foto';
            header("location: menu_edit.php?id=$id");
            exit();
        }
    }

    // Update data ke database
    $query = "UPDATE menu SET nama = '$nama', kategori_id = '$kategori_id', harga = '$harga', foto = '$foto', detail = '$detail', ketersediaan_stok = '$ketersediaan_stok' WHERE id = $id";
    mysqli_query($dbconnect, $query);

    $_SESSION['success'] = 'Berhasil mengupdate data';
    header("location: menu.php");
}

$queryKategori = mysqli_query($dbconnect, "SELECT * FROM kategori");
?>

<!DOCTYPE html>
<html>

<head>
    <title>Edit menu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6h0W+ALEwIH" crossorigin="anonymous">
</head>

<body>
    <div class="container">
        <h1>Edit menu</h1>
        <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <div class="form-group">
                <label for="nama">Nama menu</label>
                <input type="text" name="nama" class="form-control" placeholder="Nama menu" value="<?php echo $nama; ?>">
            </div>
            <div class="form-group">
                <label for="kategori">Kategori</label>
                <select name="kategori" id="kategori" class="form-control">
                    <option value="">Pilih</option>
                    <?php
                    while ($dataKategori = mysqli_fetch_array($queryKategori)) {
                    ?>
                        <option value="<?php echo $dataKategori['id']; ?>" <?php if ($kategori_id == $dataKategori['id']) echo 'selected'; ?>><?php echo $dataKategori['nama']; ?></option>
                    <?php
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="harga">Harga</label>
                <input type="number" name="harga" class="form-control" placeholder="Harga menu" value="<?php echo $harga; ?>">
            </div>
            <div class="form-group">
                <label for="foto">Foto</label>
                <input type="file" name="foto" class="form-control" id="foto">
                <img src="../img/<?php echo $foto; ?>" width="100" alt="foto">
            </div>
            <div class="form-group">
                <label for="detail">Detail</label>
                <textarea name="detail" id="detail" cols="30" rows="10" class="form-control"><?php echo $detail; ?></textarea>
            </div>
            <div class="form-group">
                <label for="ketersediaan_stok">Stock</label>
                <select name="ketersediaan_stok" id="ketersediaan_stok" class="form-control">
                    <option value="tersedia" <?php if ($ketersediaan_stok == "tersedia") echo 'selected'; ?>>Tersedia</option>
                    <option value="habis" <?php if ($ketersediaan_stok == "habis") echo 'selected'; ?>>Habis</option>
                </select>
            </div>
            <input type="submit" name="update" value="Update" class="btn btn-primary">
            <a href="menu.php" class="btn btn-primary">Kembali</a>
        </form>
    </div>
</body>

</html>
