<?php
session_start();
include '../koneksi.php';
$view = $dbconnect->query("SELECT * FROM kategori");
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <title>Kategori</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>
    <section>
        <div class="container mt-5">
            <?php
            if (isset($_SESSION['success']) && $_SESSION['success'] != '') { ?>
                <div class="alert alert-success" role="alert">
                    <?= $_SESSION['success'] ?>
                </div>
            <?php 
            } 
            $_SESSION['success'] = '';
            ?>
            
            <h1>Kategori</h1>
            <a href="kategori_add.php" class="btn btn-primary">Tambah Data</a>
            <a href="index.php" class="btn btn-primary">Logout</a>
            <table class="table table-bordered mt-3">
                <tr>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>Aksi</th>
                </tr>

                <?php
                while ($row = $view->fetch_array()) {
                ?>
                    <tr>
                        <td><?= $row['id'] ?></td>
                        <td><?= $row['nama'] ?></td>
                        <td>
                            <a href="kategori_edit.php?id=<?= $row['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                            <a href="kategori_hps.php?id=<?= $row['id'] ?>" onclick="return confirm('Yakin ingin menghapus data ini?')" class="btn btn-danger btn-sm">Hapus</a>
                        </td>
                    </tr>
                <?php
                }
                ?>
            </table>
        </div>
    </section>
</body>

</html>
