<?php
include '../koneksi.php';
session_start();

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Menghapus data dari database
    $query = "DELETE FROM menu WHERE id = $id";
    mysqli_query($dbconnect, $query);

    $_SESSION['success'] = 'Berhasil menghapus data';
    header("location: menu.php");
}
?>
