<?php
include '../koneksi.php';
session_start();

if (isset($_POST['simpan'])) {

    $nama = $_POST['nama'];
    $kategori_id = $_POST['kategori'];
    $harga = $_POST['harga'];
    $detail = $_POST['detail'];
    $ketersediaan_stok = $_POST['ketersediaan_stok'];

    $target_dir = "../img/";
    $nama_file = basename($_FILES["foto"]["name"]);
    $image_size = $_FILES["foto"]["size"];
    $target_file = $target_dir . $nama_file;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Validasi file
    if ($image_size > 0 && ($imageFileType == "jpg" || $imageFileType == "png" || $imageFileType == "jpeg")) {
        if (move_uploaded_file($_FILES["foto"]["tmp_name"], $target_file)) {
            $foto = $nama_file;

            // Save to the database
            $query = "INSERT INTO menu (id, nama, kategori_id, harga, foto, detail, ketersediaan_stok) VALUES ('','$nama', '$kategori_id', '$harga', '$foto','$detail','$ketersediaan_stok')";
            mysqli_query($dbconnect, $query);

            $_SESSION['success'] = 'Berhasil menambahkan data';
            // Redirect to the list menu page
            header("location: menu.php");
        } else {
            $_SESSION['error'] = 'Gagal mengupload foto';
        }
    } else {
        $_SESSION['error'] = 'Format file tidak valid atau tidak ada file yang diupload';
    }
}

$queryKategori = mysqli_query($dbconnect, "SELECT * FROM kategori");
?>

<!DOCTYPE html>
<html>

<head>
    <title>Tambah menu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6h0W+ALEwIH" crossorigin="anonymous">
</head>

<body>
    <div class="container">
        <h1>Tambah menu</h1>
        <form method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="nama">Nama menu</label>
                <input type="text" name="nama" class="form-control" placeholder="Nama menu">
            </div>
            <div class="form-group">
                <label for="kategori">Kategori</label>
                <select name="kategori" id="kategori" class="form-control">
                    <option value="">Pilih</option>
                    <?php
                    while ($data = mysqli_fetch_array($queryKategori)) {
                    ?>
                        <option value="<?php echo $data['id']; ?>"><?php echo $data['nama']; ?></option>
                    <?php
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="harga">Harga</label>
                <input type="number" name="harga" class="form-control" placeholder="Harga menu">
            </div>
            <div class="form-group">
                <label for="foto">Foto</label>
                <input type="file" name="foto" class="form-control" id="foto">
            </div>
            <div class="form-group">
                <label for="detail">Detail</label>
                <textarea name="detail" id="detail" cols="30" rows="10" class="form-control"></textarea>
            </div>
            <div class="form-group">
                <label for="ketersediaan_stok">Stock</label>
                <select name="ketersediaan_stok" id="ketersediaan_stok" class="form-control">
                    <option value="tersedia">Tersedia</option>
                    <option value="habis">Habis</option>
                </select>
            </div>
            <input type="submit" name="simpan" value="simpan" class="btn btn-primary">
            <a href="menu.php" class="btn btn-primary">kembali</a>
        </form>
    </div>
</body>

</html>
