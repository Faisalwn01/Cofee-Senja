<?php
session_start();
include '../koneksi.php';
if (isset($_GET['id'])) {
    
    $id = $_GET ['id'];
  

    // Save to the database
    mysqli_query($dbconnect, "DELETE FROM kategori WHERE id='$id' ");

    $_SESSION['success'] = 'Berhasil menghapus data';
    
    // Redirect to the list role page
    header("location: kategori.php");
}

?>