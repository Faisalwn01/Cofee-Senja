<?php include 'session.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,400;1,700&display=swap" rel="stylesheet">

    <!-- Feather Icons -->
    <script src="https://unpkg.com/feather-icons"></script>

    <!-- Custom CSS -->
    <link rel="stylesheet" href="../css/style.css">

    <style>
        /* Centered Text */
.centered-text {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 80vh; /* Adjust height as needed */
}

.centered-text h2 {
  text-align: center;
}
    </style>

    
</head>
<body>
    
    <?php include 'navbar.php';?>
    <div class="container mt-5">
        <div class="centered-text">
            <h2>Halo <?php echo $_SESSION['username']; ?></h2>
        </div>
    </div>

    <!-- Feather Icons Activation -->
    <script>
        feather.replace();
    </script>
</body>
</html>
