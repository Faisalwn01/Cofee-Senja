<?php
session_start();
include '../koneksi.php';
if (isset($_GET['id'])) {
    $id = $_GET ['id'];
    $data = mysqli_query($dbconnect,"SELECT * FROM kategori WHERE id='$id'");
    $data = mysqli_fetch_assoc($data);
}

if (isset($_POST['update'])) {
    
    $id = $_GET ['id'];
    $nama = $_POST['nama'];
    

    // Save to the database
    mysqli_query($dbconnect, "UPDATE kategori SET nama='$nama' WHERE id='$id'");

    $_SESSION['success'] = 'Berhasil mengedit data';
    // Redirect to the list kategori page
    header("location: kategori.php");
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Perbarui kategori</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>
    <div class="container">
        <h1>Edit kategori</h1>
        <form method="post">
            <div class="form-group">
                <label>Nama </label>
                <input type="text" name="nama" class="form-control" placeholder="Nama kategori" value="<?=$data['nama']?>">
            </div>
           
            <input type="submit" name="update" value ="Perbarui" class="btn btn-primary">
            <a href="kategori.php" class="btn btn-primary">kembali</a>
        </form>
    </div>
</body>

</html>