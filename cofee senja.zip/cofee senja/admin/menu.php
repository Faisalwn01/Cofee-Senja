<?php
include '../koneksi.php';
session_start();


if(isset($_GET['search']) && !empty($_GET['search'])) {
    $search = $_GET['search'];
    $view = $dbconnect->query("SELECT * FROM menu WHERE nama LIKE '%$search%'");
} else {
    $view = $dbconnect->query("SELECT * FROM menu");
}

?>

<!DOCTYPE html>
<html>

<head>
    <title>List menu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>




<body>
    <div class="container">
    <?php
    if(isset($_SESSION['success']) && $_SESSION['success'] !=''){?>
    <div class="alert alert-success" role="alert">
        <?=$_SESSION['success']?>
    </div>
    <?php 
    } 
        $_SESSION['success']='';
    ?>
        
        <h1>Menu</h1>
        <a href="menu_add.php" class="btn btn-primary">Tambah data</a>
        <a href="index.php" class="btn btn-primary">Logout</a>
        <div class="mb-3">
    <form method="GET">
        <div class="input-group">
            <input type="text" class="form-control" placeholder="Cari menu..." name="search">
            <button class="btn btn-primary" type="submit">Cari</button>
        </div>
    </form>
</div>
        <table class="table table-bordered">
            <tr>
                <th>ID</th>
                <th>Nama</th>
                <th>Kategori</th>
                <th>Harga</th>
                <th>Stok</th>
                <th>Aksi</th>
            
            </tr>

            <?php
            while ($row = $view->fetch_array()) {
            ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= $row['nama'] ?></td>
                    <td><?= $row['kategori_id'] ?></td>
                    <td><?= $row['harga'] ?></td>
                    <td><?= $row['ketersediaan_stok'] ?></td>
                    <td>
                        <a href="menu_edit.php?id=<?= $row['id'] ?>">Edit</a> 
                        <a href="menu_hps.php?id=<?= $row['id'] ?>"onclick="return confirm('yakin?')">Hapus</a>
                    </td>
                </tr>
            <?php
            }
            ?>
            
        </table>
    </div>
    

</body>

</html>
